/* 
 * File:   main.cpp
 * Author: Andrew Wiebe
 * Created on March 20, 2017, 1:00 PM
 * Purpose:  Input the amount of coins that you believe will add up to exactly
             1 dollar, but if you enter an amount that is either too high or
             too low, then you lose.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float penny, nickel, dime, quarter;//How many coins the user wants to add in
    
    //Initialize variables
    
    //Input data
    cout<<"Input the amount of coins that you believe will add up to exactly"
            " 1 dollar, but if you enter an amount that is either too high or"
            " too low, then you lose. "<<endl;
    cout<<"Please input how many pennies you want"<<endl;
        cin>>penny;//How may pennies the user wants
        
    cout<<"Please input how many nickels you want"<<endl;
        cin>>nickel;//How may nickels the user wants
        
    cout<<"Please input how many dimes you want"<<endl;
        cin>>dime;//How may dimes the user wants
        
    cout<<"Please input how many quarters you want"<<endl;
        cin>>quarter;//How may quarters the user wants
  
    
    float coins=(penny*1.0f)+(nickel*5.0f)+(dime*10.0f)+(quarter*25.0f);//adding cents up
    
    //Map inputs to outputs or process the data

         if(coins<100.0f)      cout<<"You have "<<coins<<" cents, which is under 1 dollar. You Lose!"<<endl;
         else if(coins>100.0f) cout<<"You have "<<coins<<" cents, which is over 1 dollar. You Lose!"<<endl;
         else if(coins=100)    cout<<"Congratulations, you have "<<coins<<" cents, which is equal to 1 dollar. You win!"<<endl;

    //Output the transformed data
    
    //Exit stage right!
    return 0;
}

