/* 
 * File:   main.cpp
 * Author: Andrew Wiebe
 * Created on March 20, 2017, 11:00 AM
 * Purpose:  Create a program that will ask the user for numbers 1-10,
 *  and will convert those into Roman numeral. 
 * The program must not accept any other number.
 */

//System Libraries
#include <iostream>
//Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables

    
    //Initialize variables
    int number;
    
    cout<<"Enter a number from 1-10"<<endl; //Asking user for numbers 1-10
    cin>>number;                            //input for the number 
    switch(number)
    {
                case 1 : cout<<"The number 1 in Roman numeral is I "<<endl;
        break;
        
                case 2 : cout<<"The number 2 in Roman numeral is II "<<endl;
        break;
        
                case 3 : cout<<"The number 3 in Roman numeral is III "<<endl;
        break;
        
                case 4 : cout<<"The number 4 in Roman numeral is IV "<<endl;
        break;
        
                case 5 : cout<<"The number 5 in Roman numeral is V "<<endl;
        break;
        
                case 6 : cout<<"The number 6 in Roman numeral is VI "<<endl;
        break;
        
                case 7 : cout<<"The number 7 in Roman numeral is VII "<<endl;
        break;
        
                case 8 : cout<<"The number 8 in Roman numeral is VIII "<<endl;
        break;
        
                case 9 : cout<<"The number 9 in Roman numeral is IX "<<endl;
        break;
        
                case 10 : cout<<"The number 10 in Roman numeral is X "<<endl;
        break;
        
        default: cout<<"You did not enter a number from 1-10"
                <<endl;//used for when number falls out of the intended range
    }

    return 0;
}

