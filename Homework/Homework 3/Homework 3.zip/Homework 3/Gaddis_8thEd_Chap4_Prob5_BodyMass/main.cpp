/* 
 * File:   main.cpp
 * Author: Andrew Wiebe
 * Created on March 20, 2017, 12:20 PM
 * Purpose:  Calculate a person's BMI and tell them whether they are
 *  above average, below average, or in the range of being healthy.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float weight, height;//How tall the person and how much they weigh
    
    //Initialize variables
    
    //Input data
    cout<<"Please input your weight in pounds."<<endl;//weight input
    cin>>weight;
    cout<<"Please input your height in inches."<<endl;//height input
    cin>>height;
           
    float myBMI=(weight * (703.0f / (height * height)));  // BMI equation
    
    //Map inputs to outputs or process the data
         if(myBMI>=18.5f && myBMI<=25.0f) cout<<"You have a healthy BMI of "<<myBMI<<endl;
    else if(myBMI<18.5f)                  cout<<"Your BMI is at "<<myBMI<<", which is below the average mark"<<endl;
    else if(myBMI>25.0f)                  cout<<"Your BMI is at "<<myBMI<<", which is above the average mark"<<endl; 

    //Output the transformed data
    
    //Exit stage right!
    return 0;
}

