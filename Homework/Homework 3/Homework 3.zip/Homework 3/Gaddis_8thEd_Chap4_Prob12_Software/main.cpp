/* 
 * File:   main.cpp
 * Author: Andrew Wiebe
 * Created on March 20, 2017, 2:20 PM
 * Purpose:  Create a program that allows the user to input the number of 
 * products bought and show the user what the final price will be with the
 *  included discount.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float quant;// quantity of products purchased
    float price;// What the final price will come to 
    
      
    //Input data
    cout<<"The program produces how much you will pay for a "
            "certain number of poducts"<<endl;
    
    cout<<"Type in any positive number"<<endl;
    cin>>quant;
    
    if(quant<0){
   cout<<"You failed to enter a number above 0, restart the"
           " program and enter a positive number"<<endl;   
        return 1;//Use DeMorgans law to make clearer
    }
    //Map inputs to outputs or process the data
    if(quant>=100)      price=((99.0f*quant)/2.0f);
    else if(quant>=50)  price=((99.0f*quant)*0.4f);
    else if(quant>=20)  price=((99.0f*quant)*0.3f);
    else if(quant>=10)  price=((99.0f*quant)*0.2f);
    else                price=(99.0f*quant);

    
    //Output the transformed data
    cout<<"If you bought "<<quant<<" of the item, then you will pay "
            <<price<<"$"<<endl;
    
    //Exit stage right!
    return 0;
}

