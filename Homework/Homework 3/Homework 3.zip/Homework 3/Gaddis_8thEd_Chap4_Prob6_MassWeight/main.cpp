/* 
 * File:   main.cpp
 * Author: Andrew Wiebe
 * Created on March 20, 2017, 1:30 PM
 * Purpose:  Input the mass of an object in kilograms to calculate the weight
 *  in newtons. Then decide whether it falls in the normal range or not.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float mass;//Mass in kilograms
    
    //Initialize variables
    
    //Input data
    cout<<"Input the mass of an object in kilograms"<<endl;
    cin>>mass;//User inputs mass
  
  
    float weight= mass * 9.8f;//Weight calculation
    
    //Map inputs to outputs or process the data

    if(weight>=10.0f && weight<=1000.0f) cout<<"The objects weight is "<<weight<<" newtons, which is within normal range."<<endl;
         else if(weight<10.0f)           cout<<"The objects weight is "<<weight<<" newtons, which is too low."<<endl;
         else if(weight>1000.0f)         cout<<"The objects weight is "<<weight<<" newtons, which is too high."<<endl; 
     

    //Output the transformed data
    
    //Exit stage right!
    return 0;
}

