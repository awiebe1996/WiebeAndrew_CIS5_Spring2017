/* 
 * File:   main.cpp
 * Author: Andrew Wiebe
 * Created on March 20, 2017, 12:00 PM
 * Purpose:  Create a program that asks the user for measurements of two
 *  rectangles and the shows which has the greater area, or if they are
 *  the same.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float width1, length1;  //side measures of rectangle 1
    float width2, length2;  //side measures of rectangle 2
    float area1, area2;     //The areas of the two rectangles
    
    //Input data
    cout<<"The program shows the bigger area of the two rectangles"<<endl;
    
    cout<<"Type in the length of the first rectangle"<<endl;
        cin>>length1;
        
    cout<<"Type in the width of the first rectangle"<<endl;
        cin>>width1;
        
    cout<<"Type in the length of the second rectangle"<<endl;
        cin>>length2;
        
    cout<<"Type in the width of the second rectangle"<<endl;
        cin>>width2;

        area1=length1*width1; //computation for the area of the first rectangle
        area2=length2*width2; //computation for the area of the first rectangle
        
    
    //Map inputs to outputs or process the data

        
     if(area1>area2) cout<<"The first rectangle has the bigger area"<<endl;
        else if(area1<area2) cout<<"The second rectangle has the bigger area"<<endl;
        else if(area1=area2)cout<<"The two rectangles area's are the same."<<endl;
          
    //Output the transformed data
     
    //Exit stage right!
    return 0;
}

