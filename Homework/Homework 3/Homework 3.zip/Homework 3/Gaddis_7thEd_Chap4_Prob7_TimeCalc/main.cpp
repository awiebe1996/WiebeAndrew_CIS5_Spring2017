/* 
 * File:   main.cpp
 * Author: Andrew Wiebe
 * Created on March 14, 2017, 11:20 AM
 * Purpose:  Time calculator/converter
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants
const int MINUTE=60;        //How many seconds are in a minute
const int HOUR=60*MINUTE;   //How many seconds are in a hour
const int DAY=24*HOUR;      //How many seconds are in a day
const int WEEK=7*DAY;       //How many seconds are in a week
const int YEAR=52*WEEK;     //How many seconds are in a year

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    int nSecs;//Number of seconds to convert
    int nYrs,nMnths,nWks,nDys,nHrs,nMin;
    
    //Initialize variables
    cout<<"This program converts seconds to Years/Months/Weeks/Days/Hours"<<endl;
    cout<<"Input the number of seconds for the conversion/equivalence"<<endl;
    cin>>nSecs;

    //Map inputs to outputs or process the data
    nYrs=nSecs/YEAR;        //Number of years
    cout<<nYrs<<" Years (";
    nSecs-=nYrs*YEAR;       //Subtract the yearly seconds from the remaining
    
    nWks=nSecs/WEEK;        //Number of weeks
    cout<<nWks<<" Weeks or ";
    nMnths=nWks*3/13;       //Convert number of weeks to months
    cout<<nMnths<<" Months) ";
    nSecs-=nWks*WEEK;       //Subtract the weekly seconds from the remaining
   
    nDys=nSecs/DAY;         //Number of days
    cout<<nDys<<" Days ";
    nSecs-=nDys*DAY;        //Subtract the daily seconds from the remaining
   
    nHrs=nSecs/HOUR;        //Number of hours
    cout<<nHrs<<" Hours ";
    nSecs-=nHrs*HOUR;       //Subtract the hourly seconds from the remaining
   
    nMin=nSecs/MINUTE;      //Number of minutes 
    cout<<nMin<<" Minutes ";
   
    nSecs-=nMin*MINUTE;     //Remaining number of seconds
    cout<<nSecs<<" Seconds";
    
    //Exit stage right!
    return 0;
}

