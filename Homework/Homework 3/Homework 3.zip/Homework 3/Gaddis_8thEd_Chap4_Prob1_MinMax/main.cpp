/* 
 * File:   main.cpp
 * Author: Andrew Wiebe
 * Created on March 20, 2017, 10:20 AM
 * Purpose:  Create a program that asks the user for two numbers then shows
 *  which one is the bigger one.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    float number1, number2; //The two numbers that are to be input
    
    //Initialize variables
    
    //Input data
    cout<<"The program shows the bigger number of the two"<<endl;
    cout<<"Type in the first number"<<endl;
    cin>>number1;
    cout<<"Type in the second number"<<endl;
    cin>>number2;
    
    //Map inputs to outputs or process the data
     if(number1>number2)       cout<<"The bigger number of the two is "
             <<number1<<endl;
    
     else if(number1<number2)  cout<<"The bigger number of the two is "
             <<number2<<endl;
     
     else cout<<"Please start over with two numbers that are not equal"<<endl;
     
    //Output the transformed data
     
    //Exit stage right!
    return 0;
}

