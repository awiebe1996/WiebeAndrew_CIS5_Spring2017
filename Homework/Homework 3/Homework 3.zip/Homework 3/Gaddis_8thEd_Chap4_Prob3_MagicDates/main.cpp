/* 
 * File:   main.cpp
 * Author: Andrew Wiebe
 * Created on March 20, 2017, 02:40 AM
 * Purpose:  TCreate a program that will tell the user if the dates that
 *  are input are magic dates or not.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
   int year;    //the current year
   int month;   //the current month
   int day;     //the current day
    
    //Initialize variables 
   
    //Input data
   cout<<"Please enter the day as two digits"<<endl;
   cin>>day;
      cout<<"Please enter the month as two digits"<<endl;
   cin>>month;
      cout<<"Please enter the last two digits of the year"<<endl;
   cin>>year;
   
   int dayMnth=day*month;//day and month multiplied together

   
    //Map inputs to outputs or process the data
    if(year==dayMnth) cout<<"This date is magic";
    else cout<<"This date is not magic";
    
    //Output the transformed data
    
    //Exit stage right!
    return 0;
}

