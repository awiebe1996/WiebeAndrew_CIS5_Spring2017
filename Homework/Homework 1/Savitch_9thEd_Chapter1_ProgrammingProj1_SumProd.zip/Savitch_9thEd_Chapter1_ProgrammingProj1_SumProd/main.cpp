/* 
 * File:   main.cpp
 * Author: Andrew Wiebe
 * Created on Febuary 16, 2017, 11:55 AM
 * Purpose: Calculate the sum and product of two integers
 */

//System Libraries 
#include <iostream> //Input - Output Library
#include <cstdlib>   //Random number generator
#include <ctime>    //Time library to seed the random number generator
using namespace std;    //Name-space under which system libraries exist

//User Libraries Here

//Global Constants

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare variables
    srand(static_cast<unsigned int>(time(0)));
    
        //Declare variables
    short op1, op2, sum,prod;
    
    //Input or initialize values Here
    op1=rand()%171+10;// 10-180
    op2=rand()%171+10;//10-180
    
    //Input data
    
    //Map inputs to outputs of process the data
    sum=op1+op2;
    prod=op1*op2;
    
    //Output the transfered data
    cout<<op1<<" + "<<op2<<" = "<<sum<<endl;
    cout<<op1<<" x "<<op2<<" = "<<prod<<endl;

    //Exit stage right!
    return 0;
}

